# Oasis Suspendido

Port del proyecto raylib "Project: Aether-Grid" a Godot 4.3+. La escena
actual tiene cámara amplia, personajes pixel-art, combate, progresión, slimes,
decoración, interacciones y dos zonas conectadas.

## Cómo abrirlo

1. Abre Godot 4.3 o superior.
2. Importa la carpeta `oasis-suspendido-godot` seleccionando su archivo
   `project.godot`.
3. Pulsa F6/F5 para ejecutar la escena.
4. Muévete con WASD o las flechas.

## Controles

- WASD o flechas: mover al personaje.
- Espacio o J: ataque principal de la clase.
- Q: habilidad especial de la clase.
- E: interactuar con altar, cofre o salida.
- 1: Arquero.
- 2: Guerrero.
- 3: Mago.
- 4: Asesino.

## Cambios incluidos

- La cámara pasó de `zoom = 2` a `zoom = 1`, por lo que conserva el tamaño
  de los personajes pero muestra prácticamente el doble de mundo alrededor.
- Se mantuvieron los límites del mapa y se activó el suavizado de cámara para
  que el campo ampliado no se sienta brusco.
- Se integraron las láminas de arquero, guerrero, mago y asesino, además de
  los slimes rojo, verde y azul. Los recortes se guardan en
  `assets/sprites/` con animaciones de reposo, caminar, ataque y daño.
- El terreno tiene más contraste, agua animada, rocas con grietas y detalles
  de arena. La zona también incluye altar, cofres, antorchas, cristales,
  palmeras, flores y señales.
- Cada clase tiene ataque y habilidad propios: flechas a distancia, tajo y
  giro, orbe y nova, o corte y paso sombrío.
- Los slimes atacan al jugador, reciben daño, mueren y otorgan experiencia.
  El jugador sube de nivel, aumenta su vida, acumula oro y reaparece en el
  altar después de caer.
- El altar cura, el cofre entrega oro y experiencia y desbloquea la salida.
  La salida encadena el Santuario Hundido con el Bosque de la Grieta, que
  también permite regresar a la primera zona.

## Estructura

- `scenes/Main.tscn`: escena principal y cámara.
- `scripts/world/world.gd`: generación determinista, decoración, interacciones
  y transición entre zonas.
- `scripts/world/world_grid.gd`: terreno, detalles pixel-art y colisiones.
- `scripts/world/world_decor.gd`: objetos decorativos de la zona.
- `scripts/entities/player.gd`: movimiento, clases, combate, progresión y
  respawn.
- `scripts/entities/slime.gd`: enemigos móviles con daño y recompensas.
- `scripts/ui/game_hud.gd`: HUD y controles visibles.
- `assets/reference/`: láminas originales usadas como referencia.
- `assets/sprites/`: texturas recortadas listas para Godot.

La escena fue validada con Godot 4.3 en modo sin interfaz y las comprobaciones
directas confirmaron cambio de clase, niveles, altar, cofre, salida y regreso
entre zonas.