extends RefCounted
class_name TileKind

enum {
	VOID = 0,
	FLOOR,
	SAND,
	GRASS,
	WATER,
	WALL,
	ROCK,
}

const TILE_SIZE := 32

const TABLE := [
	{"solid": true,  "destructible": false, "base": Color8(8, 10, 24),  "detail": Color8(8, 10, 24)},
	{"solid": false, "destructible": false, "base": Color8(39, 42, 67), "detail": Color8(76, 76, 111)},
	{"solid": false, "destructible": false, "base": Color8(91, 70, 56), "detail": Color8(151, 112, 77)},
	{"solid": false, "destructible": false, "base": Color8(43, 76, 64), "detail": Color8(79, 137, 93)},
	{"solid": true,  "destructible": false, "base": Color8(29, 74, 104), "detail": Color8(86, 177, 191)},
	{"solid": true,  "destructible": false, "base": Color8(28, 27, 48), "detail": Color8(102, 92, 141)},
	{"solid": true,  "destructible": true,  "base": Color8(71, 62, 92), "detail": Color8(139, 117, 157)},
]

static func info(kind: int) -> Dictionary:
	if kind < 0 or kind >= TABLE.size():
		return TABLE[VOID]
	return TABLE[kind]

static func is_solid(kind: int) -> bool:
	return info(kind)["solid"]

static func is_destructible(kind: int) -> bool:
	return info(kind)["destructible"]