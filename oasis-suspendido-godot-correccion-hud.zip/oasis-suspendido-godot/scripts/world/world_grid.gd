extends Node2D
class_name WorldGrid

const TILE_SIZE := TileKind.TILE_SIZE

var width := 0
var height := 0
var tiles: PackedInt32Array = PackedInt32Array()
var _time := 0.0
var _view_rect := Rect2()

func resize(new_width: int, new_height: int, fill: int = TileKind.VOID) -> void:
	width = max(new_width, 0)
	height = max(new_height, 0)
	tiles.resize(width * height)
	for i in range(tiles.size()):
		tiles[i] = fill

func fill_circle(center_x: int, center_y: int, radius_in_tiles: float, kind: int) -> void:
	var min_x := int(floor(center_x - radius_in_tiles))
	var max_x := int(ceil(center_x + radius_in_tiles))
	var min_y := int(floor(center_y - radius_in_tiles))
	var max_y := int(ceil(center_y + radius_in_tiles))
	for y in range(min_y, max_y + 1):
		for x in range(min_x, max_x + 1):
			var dx := float(x - center_x)
			var dy := float(y - center_y)
			if dx * dx + dy * dy <= radius_in_tiles * radius_in_tiles:
				set_tile(x, y, kind)

func in_bounds(x: int, y: int) -> bool:
	return x >= 0 and y >= 0 and x < width and y < height

func get_tile(x: int, y: int) -> int:
	if not in_bounds(x, y):
		return TileKind.VOID
	return tiles[y * width + x]

func set_tile(x: int, y: int, kind: int) -> void:
	if in_bounds(x, y):
		tiles[y * width + x] = kind

static func tile_to_world(x: int, y: int) -> Vector2:
	return Vector2(x * TILE_SIZE, y * TILE_SIZE)

static func tile_center_to_world(x: float, y: float) -> Vector2:
	return Vector2(x * TILE_SIZE + TILE_SIZE / 2.0, y * TILE_SIZE + TILE_SIZE / 2.0)

static func world_to_tile(coord: float) -> int:
	return int(floor(coord / float(TILE_SIZE)))

func is_solid(x: int, y: int) -> bool:
	if not in_bounds(x, y):
		return true
	return TileKind.is_solid(get_tile(x, y))

func is_solid_at(world_point: Vector2) -> bool:
	return is_solid(world_to_tile(world_point.x), world_to_tile(world_point.y))

func check_collision(bounds: Rect2) -> bool:
	if width <= 0 or height <= 0:
		return false
	var min_x := world_to_tile(bounds.position.x)
	var min_y := world_to_tile(bounds.position.y)
	var max_x := world_to_tile(bounds.position.x + bounds.size.x)
	var max_y := world_to_tile(bounds.position.y + bounds.size.y)
	for y in range(min_y, max_y + 1):
		for x in range(min_x, max_x + 1):
			if not is_solid(x, y):
				continue
			var tile_rect := Rect2(tile_to_world(x, y), Vector2(TILE_SIZE, TILE_SIZE))
			if bounds.intersects(tile_rect):
				return true
	return false

func set_view(view_rect: Rect2, time: float) -> void:
	_view_rect = view_rect
	_time = time
	queue_redraw()

func _draw() -> void:
	if width <= 0 or height <= 0:
		return
	var min_x := clampi(world_to_tile(_view_rect.position.x) - 1, 0, width - 1)
	var min_y := clampi(world_to_tile(_view_rect.position.y) - 1, 0, height - 1)
	var max_x := clampi(world_to_tile(_view_rect.end.x) + 1, 0, width - 1)
	var max_y := clampi(world_to_tile(_view_rect.end.y) + 1, 0, height - 1)
	for y in range(min_y, max_y + 1):
		for x in range(min_x, max_x + 1):
			var kind := get_tile(x, y)
			if kind == TileKind.VOID:
				continue
			var info := TileKind.info(kind)
			var px := x * TILE_SIZE
			var py := y * TILE_SIZE
			draw_rect(Rect2(px, py, TILE_SIZE, TILE_SIZE), info["base"])
			_draw_tile_detail(x, y, kind, info, px, py)

func _tile_hash(x: int, y: int) -> int:
	var h := ((x * 73856093) ^ (y * 19349663)) & 0xFFFFFFFF
	h = (h ^ (h >> 13)) & 0xFFFFFFFF
	h = (h * 1274126177) & 0xFFFFFFFF
	return (h ^ (h >> 16)) & 0xFFFFFFFF

func _lighten(color: Color, amount: float) -> Color:
	return Color(
		clampf(color.r + amount, 0.0, 1.0),
		clampf(color.g + amount, 0.0, 1.0),
		clampf(color.b + amount, 0.0, 1.0),
		color.a
	)

func _draw_tile_detail(tx: int, ty: int, kind: int, info: Dictionary, px: int, py: int) -> void:
	var h := _tile_hash(tx, ty)
	match kind:
		TileKind.FLOOR:
			draw_rect(Rect2(px + 2, py + 2, TILE_SIZE - 4, 1), Color(0.31, 0.31, 0.46, 0.14))
			draw_rect(Rect2(px + 5 + (h & 0x0F), py + 5 + ((h >> 8) & 0x0F), 2, 2), info["detail"])
			draw_rect(Rect2(px + 12 + ((h >> 16) & 0x0F), py + 16 + ((h >> 24) & 0x0F), 1, 1), info["detail"])
		TileKind.SAND:
			draw_rect(Rect2(px + 4 + (h & 0x0F), py + 4 + ((h >> 6) & 0x0F), 2, 2), info["detail"])
			draw_rect(Rect2(px + 10 + ((h >> 12) & 0x0F), py + 12 + ((h >> 18) & 0x0F), 2, 1), info["detail"])
			draw_line(Vector2(px + 6, py + 23), Vector2(px + 12, py + 22), Color(info["detail"], 0.44), 1.0)
		TileKind.WATER:
			var wave := sin(_time * 2.4 + float(tx + ty) * 0.7)
			var line_y := py + 13 + int(wave * 3.0)
			draw_line(Vector2(px + 4, line_y), Vector2(px + TILE_SIZE - 5, line_y), info["detail"], 2.0)
			draw_line(Vector2(px + 11, line_y + 8), Vector2(px + TILE_SIZE - 8, line_y + 8), Color(info["detail"], 0.45), 1.0)
		TileKind.WALL:
			draw_rect(Rect2(px + 2, py + 2, TILE_SIZE - 4, TILE_SIZE - 4), info["base"])
			draw_rect(Rect2(px, py, TILE_SIZE, 3), _lighten(info["base"], 0.12))
			draw_line(Vector2(px + 5, py + 10), Vector2(px + 26, py + 10), Color(info["detail"], 0.55), 2.0)
		TileKind.ROCK:
			draw_rect(Rect2(px + 1, py + 1, TILE_SIZE - 2, TILE_SIZE - 2), info["base"])
			var crack_x := px + 10 + (h % 12)
			draw_line(Vector2(crack_x, py + 5), Vector2(crack_x - 5, py + TILE_SIZE / 2.0), info["detail"], 2.0)
			draw_line(Vector2(crack_x - 5, py + TILE_SIZE / 2.0), Vector2(crack_x + 3, py + TILE_SIZE - 5), info["detail"], 2.0)
			draw_circle(Vector2(px + 8, py + 8), 2.0, Color(info["detail"], 0.58))