extends Node2D
class_name World

signal zone_changed(zone_name: String)

@export var player_path: NodePath

const ROCK_NOISE_SCALE := 0.14
const ROCK_NOISE_OFFSET_X := 37.0
const ROCK_NOISE_OFFSET_Y := 91.0

var grid: WorldGrid
var params: ZoneParams
var spawn_point := Vector2.ZERO
var current_zone_id := "sanctuary"
var zone_name := "Santuario Hundido"
var altar_used := false
var chest_opened := false
var exit_unlocked := false
var _elapsed := 0.0
var _decor: WorldDecor
var _decor_props: Array[Dictionary] = []

func _ready() -> void:
	_load_zone("sanctuary")

func _load_zone(zone_id: String) -> void:
	current_zone_id = zone_id
	params = ZoneParams.for_zone(zone_id)
	altar_used = false
	chest_opened = false
	exit_unlocked = zone_id == "rift_forest"
	generate(params)
	zone_name = params.zone_name
	zone_changed.emit(zone_name)
	_clear_slimes()
	call_deferred("_spawn_slimes")

func enter_next_zone() -> String:
	if current_zone_id != "sanctuary":
		return "Ya estás en la zona más profunda"
	_load_zone("rift_forest")
	_place_player_at_spawn()
	return "Has llegado al Bosque de la Grieta"

func enter_previous_zone() -> String:
	if current_zone_id != "rift_forest":
		return "No hay una zona anterior"
	_load_zone("sanctuary")
	_place_player_at_spawn()
	return "Has regresado al Santuario Hundido"

func get_zone_label() -> String:
	return zone_name

func generate(new_params: ZoneParams) -> void:
	params = new_params
	if grid == null:
		grid = WorldGrid.new()
		add_child(grid)
	grid.resize(params.width, params.height, TileKind.FLOOR)
	var noise := Noise2D.new(params.seed_value)

	for y in range(params.height):
		for x in range(params.width):
			var ground_noise := noise.fbm(x * params.sand_scale, y * params.sand_scale, 3)
			grid.set_tile(x, y, params.ground_tile if ground_noise > params.sand_threshold else TileKind.FLOOR)

	for y in range(params.height):
		for x in range(params.width):
			var rock_noise := noise.fbm(
				x * ROCK_NOISE_SCALE + ROCK_NOISE_OFFSET_X,
				y * ROCK_NOISE_SCALE + ROCK_NOISE_OFFSET_Y,
				3
			)
			if rock_noise > params.rock_threshold:
				grid.set_tile(x, y, TileKind.ROCK)

	if params.pond:
		var pond_x := 0.22 if noise.value(11.3, 4.7) < 0.5 else 0.78
		var pond_y := 0.24 if noise.value(91.1, 17.9) < 0.5 else 0.76
		var radius := 3.5 + noise.value(2.0, 8.0) * 2.5
		grid.fill_circle(int(params.width * pond_x), int(params.height * pond_y), radius, TileKind.WATER)

	for y in range(params.height):
		for x in range(params.width):
			if _is_border_tile(x, y):
				grid.set_tile(x, y, TileKind.WALL)

	spawn_point = WorldGrid.tile_center_to_world(params.width / 2.0, params.height / 2.0)
	_carve_around(spawn_point, 3.5, TileKind.FLOOR)
	_create_decor()

func _create_decor() -> void:
	if _decor != null:
		_decor.queue_free()
	_decor = null
	_decor_props = []
	_decor = WorldDecor.new()
	_decor.name = "EnvironmentDecor"
	add_child(_decor)

	var exit_position := spawn_point + Vector2(294, 0) if current_zone_id == "sanctuary" else spawn_point + Vector2(-294, 0)
	_decor_props = [
		{"id": "altar", "kind": "altar", "position": spawn_point + Vector2(0, -82), "used": altar_used},
		{"id": "chest", "kind": "chest", "position": spawn_point + Vector2(82, 20), "opened": chest_opened},
		{"id": "exit", "kind": "exit", "position": exit_position, "unlocked": exit_unlocked},
		{"id": "sign", "kind": "sign", "position": spawn_point + Vector2(-82, 20)},
		{"id": "torch", "kind": "torch", "position": spawn_point + Vector2(-58, -84)},
		{"id": "torch", "kind": "torch", "position": spawn_point + Vector2(58, -84)},
	]
	if current_zone_id == "rift_forest":
		_decor_props[1]["id"] = "forest_chest"

	var palm_points := [
		Vector2(250, 245), Vector2(1510, 230), Vector2(260, 905),
		Vector2(1510, 910), Vector2(730, 290), Vector2(1100, 900),
	]
	for i in range(palm_points.size()):
		_decor_props.append({"kind": "palm", "position": palm_points[i], "variant": i})

	var crystal_points := [
		Vector2(350, 520), Vector2(1450, 560), Vector2(760, 870),
		Vector2(1080, 250), Vector2(1560, 680),
	]
	for i in range(crystal_points.size()):
		_decor_props.append({"kind": "crystal", "position": crystal_points[i], "variant": i})

	for i in range(18):
		var x := 120.0 + float((i * 271) % 1540)
		var y := 150.0 + float((i * 173) % 850)
		var point := Vector2(x, y)
		if point.distance_to(spawn_point) > 125.0:
			_decor_props.append({"kind": "flower", "position": point, "variant": i})
	for i in range(10):
		var rock_point := Vector2(150.0 + float((i * 419) % 1450), 180.0 + float((i * 257) % 760))
		if rock_point.distance_to(spawn_point) > 140.0:
			_decor_props.append({"kind": "rock", "position": rock_point, "variant": i})
	_decor.set_props(_decor_props)

func _clear_slimes() -> void:
	for child in get_children():
		if child is Slime:
			child.queue_free()

func _place_player_at_spawn() -> void:
	var player := get_node_or_null(player_path) as Player
	if player != null:
		player.position = spawn_point
		player.velocity = Vector2.ZERO
		player.knockback = Vector2.ZERO

func _spawn_slimes() -> void:
	var positions := [
		Vector2(430, 350), Vector2(1330, 330), Vector2(420, 850),
		Vector2(1380, 825), Vector2(1130, 470), Vector2(630, 730),
	]
	if current_zone_id == "rift_forest":
		positions = [
			Vector2(330, 280), Vector2(1440, 290), Vector2(360, 830),
			Vector2(1410, 850), Vector2(1120, 420), Vector2(690, 760),
		]
	for i in range(positions.size()):
		var slime := Slime.new()
		slime.name = "Slime_%02d" % i
		slime.variant = ["green", "red", "blue"][i % 3]
		slime.world_path = get_path()
		slime.position = _find_free_position(positions[i])
		add_child(slime)

func _find_free_position(candidate: Vector2) -> Vector2:
	var point := candidate
	for i in range(10):
		if not check_collision(Rect2(point - Vector2(10, 8), Vector2(20, 16))):
			return point
		point += Vector2(32, 0)
	return spawn_point + Vector2(180, 0)

func interact_at(point: Vector2) -> String:
	for prop in _decor_props:
		var prop_position: Vector2 = prop.get("position", Vector2.ZERO)
		if point.distance_to(prop_position) > 42.0:
			continue
		var prop_id := str(prop.get("id", ""))
		match prop_id:
			"altar":
				altar_used = true
				prop["used"] = true
				_refresh_decor()
				var player := get_node_or_null(player_path) as Player
				if player != null:
					player.health = player.max_health
					player.stats_changed.emit()
				return "Altar activado: vitalidad restaurada"
			"chest":
				if chest_opened:
					return "El cofre está vacío"
				chest_opened = true
				exit_unlocked = true
				prop["opened"] = true
				_refresh_decor()
				var chest_player := get_node_or_null(player_path) as Player
				if chest_player != null:
					chest_player.add_gold(25)
					chest_player.gain_experience(30)
				return "Cofre abierto: +25 oro, +30 XP. Salida desbloqueada"
			"forest_chest":
				if bool(prop.get("opened", false)):
					return "El cofre del bosque está vacío"
				prop["opened"] = true
				_refresh_decor()
				var forest_player := get_node_or_null(player_path) as Player
				if forest_player != null:
					forest_player.add_gold(40)
					forest_player.gain_experience(45)
				return "Cofre del bosque: +40 oro, +45 XP"
			"exit":
				if not exit_unlocked:
					return "La salida está sellada. Abre el cofre primero"
				if current_zone_id == "sanctuary":
					return enter_next_zone()
				return enter_previous_zone()
	return ""

func _refresh_decor() -> void:
	if _decor != null:
		_decor.set_props(_decor_props)

func _is_border_tile(x: int, y: int) -> bool:
	return x < params.border_thickness or y < params.border_thickness \
		or x >= params.width - params.border_thickness \
		or y >= params.height - params.border_thickness

func _carve_around(world_point: Vector2, radius_in_tiles: float, kind: int) -> void:
	var center_x := WorldGrid.world_to_tile(world_point.x)
	var center_y := WorldGrid.world_to_tile(world_point.y)
	var reach := int(ceil(radius_in_tiles))
	for y in range(center_y - reach, center_y + reach + 1):
		for x in range(center_x - reach, center_x + reach + 1):
			if not grid.in_bounds(x, y) or _is_border_tile(x, y):
				continue
			var dx := float(x - center_x)
			var dy := float(y - center_y)
			if dx * dx + dy * dy <= radius_in_tiles * radius_in_tiles:
				grid.set_tile(x, y, kind)

func check_collision(bounds: Rect2) -> bool:
	return grid != null and grid.check_collision(bounds)

func get_spawn_point() -> Vector2:
	return spawn_point

func get_world_size() -> Vector2:
	return Vector2(grid.width * TileKind.TILE_SIZE, grid.height * TileKind.TILE_SIZE)

func _process(delta: float) -> void:
	_elapsed += delta
	if grid == null:
		return
	var camera := get_viewport().get_camera_2d()
	var view_size := get_viewport_rect().size
	var view_rect := Rect2(Vector2.ZERO, get_world_size())
	if camera != null:
		view_size /= camera.zoom
		view_rect = Rect2(camera.global_position - view_size / 2.0, view_size)
	grid.set_view(view_rect, _elapsed)