extends RefCounted
class_name Noise2D

# Equivalente a Noise.hpp/Noise.cpp: ruido de valor 2D por hash, determinista.
# La misma semilla produce siempre la misma zona (nada de rand() global), asi
# que una zona se puede reproducir guardando solo su entero de semilla.

var seed_value: int

func _init(seed_in: int = 1337) -> void:
	seed_value = seed_in

static func _smooth(t: float) -> float:
	return t * t * (3.0 - 2.0 * t)

static func _hash(x: int, y: int, s: int) -> int:
	var h := (x * 374761393 + y * 668265263 + s * 2246822519) & 0xFFFFFFFF
	h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
	return (h ^ (h >> 16)) & 0xFFFFFFFF

func _lattice(x: int, y: int) -> float:
	var h := _hash(x, y, seed_value)
	return float(h & 0xFFFFFF) / float(0xFFFFFF)

func value(x: float, y: float) -> float:
	var x0 := int(floor(x))
	var y0 := int(floor(y))
	var tx := _smooth(x - x0)
	var ty := _smooth(y - y0)

	var v00 := _lattice(x0, y0)
	var v10 := _lattice(x0 + 1, y0)
	var v01 := _lattice(x0, y0 + 1)
	var v11 := _lattice(x0 + 1, y0 + 1)

	var top := v00 + (v10 - v00) * tx
	var bottom := v01 + (v11 - v01) * tx
	return top + (bottom - top) * ty

# Suma de octavas en [0, 1]: la primera da la forma general, las siguientes
# anaden detalle pequeno (vetas, islas, bordes irregulares).
func fbm(x: float, y: float, octaves: int) -> float:
	var total := 0.0
	var amplitude := 0.5
	var frequency := 1.0
	var normalizer := 0.0

	for i in range(octaves):
		total += value(x * frequency, y * frequency) * amplitude
		normalizer += amplitude
		amplitude *= 0.5
		frequency *= 2.0

	return total / normalizer if normalizer > 0.0 else 0.0
