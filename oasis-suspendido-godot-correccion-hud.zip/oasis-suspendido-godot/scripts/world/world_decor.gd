extends Node2D
class_name WorldDecor

var props: Array[Dictionary] = []
var _time := 0.0

func set_props(new_props: Array[Dictionary]) -> void:
	props = new_props
	queue_redraw()

func _process(delta: float) -> void:
	_time += delta
	queue_redraw()

func _draw() -> void:
	for prop in props:
		var point: Vector2 = prop.get("position", Vector2.ZERO)
		match prop.get("kind", ""):
			"palm":
				_draw_palm(point, int(prop.get("variant", 0)))
			"crystal":
				_draw_crystal(point, int(prop.get("variant", 0)))
			"rock":
				_draw_rock(point, int(prop.get("variant", 0)))
			"altar":
				_draw_altar(point, bool(prop.get("used", false)))
			"chest":
				_draw_chest(point, bool(prop.get("opened", false)))
			"exit":
				_draw_exit(point, bool(prop.get("unlocked", false)))
			"torch":
				_draw_torch(point)
			"sign":
				_draw_sign(point)
			"flower":
				_draw_flower(point, int(prop.get("variant", 0)))

func _draw_palm(point: Vector2, variant: int) -> void:
	var trunk := Color8(116, 72, 73)
	var leaf := Color8(93, 147, 125) if variant % 2 == 0 else Color8(129, 167, 96)
	draw_line(point + Vector2(0, 20), point + Vector2(-3, -13), trunk, 6.0)
	draw_line(point + Vector2(-2, -2), point + Vector2(-17, -14), leaf, 4.0)
	draw_line(point + Vector2(-1, -4), point + Vector2(14, -17), leaf, 4.0)
	draw_line(point + Vector2(-2, -6), point + Vector2(0, -27), leaf, 4.0)
	draw_line(point + Vector2(-4, -4), point + Vector2(-12, -27), leaf, 3.0)
	draw_line(point + Vector2(1, -4), point + Vector2(18, -5), leaf, 3.0)
	draw_circle(point + Vector2(-1, -9), 6.0, Color(leaf, 0.5))

func _draw_crystal(point: Vector2, variant: int) -> void:
	var crystal_color := Color8(173, 115, 222) if variant % 2 == 0 else Color8(86, 190, 201)
	var dark := Color(crystal_color, 0.32)
	var back := PackedVector2Array([
		point + Vector2(-18, 13), point + Vector2(-10, -11),
		point + Vector2(-2, 6), point + Vector2(5, -23),
		point + Vector2(15, 10),
	])
	draw_colored_polygon(back, dark)
	draw_colored_polygon(PackedVector2Array([
		point + Vector2(-12, 12), point + Vector2(-6, -7),
		point + Vector2(1, 5), point + Vector2(5, -17),
		point + Vector2(10, 12),
	]), crystal_color)
	draw_line(point + Vector2(5, -15), point + Vector2(5, 8), Color(0.93, 0.79, 1.0, 0.7), 2.0)

func _draw_rock(point: Vector2, variant: int) -> void:
	var rock_color := Color8(70, 65, 101) if variant % 2 == 0 else Color8(81, 76, 118)
	var highlight := Color(rock_color, 0.78)
	draw_colored_polygon(PackedVector2Array([
		point + Vector2(-20, 11), point + Vector2(-12, -9),
		point + Vector2(2, -18), point + Vector2(18, -4),
		point + Vector2(20, 11),
	]), rock_color)
	draw_line(point + Vector2(-9, -7), point + Vector2(2, -14), highlight, 3.0)
	draw_line(point + Vector2(3, -13), point + Vector2(12, -4), Color(0.15, 0.14, 0.25, 0.8), 2.0)

func _draw_altar(point: Vector2, used: bool) -> void:
	draw_circle(point, 38.0 + sin(_time * 1.4) * 2.0, Color(0.44, 0.27, 0.72, 0.08))
	draw_rect(Rect2(point + Vector2(-22, -8), Vector2(44, 23)), Color8(67, 56, 98))
	draw_rect(Rect2(point + Vector2(-18, -19), Vector2(36, 13)), Color8(111, 85, 142))
	draw_line(point + Vector2(-13, -13), point + Vector2(13, -13), Color8(221, 176, 192), 2.0)
	draw_circle(point + Vector2(0, -29), 6.0, Color8(135, 222, 178) if used else Color8(236, 184, 217))
	draw_circle(point + Vector2(0, -29), 13.0 + sin(_time * 2.0) * 2.0, Color(0.79, 0.46, 0.92, 0.18), false, 2.0)

func _draw_chest(point: Vector2, opened: bool) -> void:
	draw_rect(Rect2(point + Vector2(-15, -6), Vector2(30, 22)), Color8(111, 74, 85))
	var lid_color := Color8(111, 101, 125) if opened else Color8(183, 127, 112)
	draw_rect(Rect2(point + Vector2(-18, -10), Vector2(36, 8)), lid_color)
	draw_line(point + Vector2(-15, 0), point + Vector2(15, 0), Color8(243, 197, 124), 3.0)
	draw_rect(Rect2(point + Vector2(-3, -2), Vector2(6, 8)), Color8(134, 123, 146) if opened else Color8(240, 203, 118))

func _draw_exit(point: Vector2, unlocked: bool) -> void:
	var portal_color := Color8(105, 205, 178) if unlocked else Color8(106, 88, 132)
	draw_circle(point, 28.0 + sin(_time * 2.0) * 2.0, Color(portal_color, 0.12))
	draw_arc(point, 22.0, 0.0, TAU, 24, portal_color, 4.0)
	draw_arc(point, 14.0, PI, TAU, 16, Color(240, 208, 157, 0.75), 2.0)
	draw_line(point + Vector2(-8, 14), point + Vector2(8, 14), portal_color, 3.0)

func _draw_torch(point: Vector2) -> void:
	draw_line(point + Vector2(0, 20), point + Vector2(0, -6), Color8(126, 78, 83), 5.0)
	var pulse := 1.0 + sin(_time * 7.0 + point.x) * 0.1
	draw_circle(point + Vector2(0, -14), 15.0 * pulse, Color(1.0, 0.47, 0.28, 0.12))
	draw_colored_polygon(PackedVector2Array([
		point + Vector2(-7, -10), point + Vector2(0, -28),
		point + Vector2(8, -10), point + Vector2(0, -5),
	]), Color8(255, 176, 91))

func _draw_sign(point: Vector2) -> void:
	draw_line(point + Vector2(0, 22), point + Vector2(0, -7), Color8(111, 75, 83), 4.0)
	draw_rect(Rect2(point + Vector2(-20, -20), Vector2(40, 17)), Color8(191, 134, 112))
	draw_line(point + Vector2(-13, -14), point + Vector2(12, -14), Color8(67, 48, 73), 2.0)

func _draw_flower(point: Vector2, variant: int) -> void:
	var flower_color := Color8(234, 154, 204) if variant % 2 == 0 else Color8(236, 191, 108)
	draw_line(point + Vector2(0, 7), point + Vector2(0, -4), Color8(91, 153, 112), 2.0)
	draw_circle(point + Vector2(0, -7), 4.0, flower_color)
	draw_circle(point + Vector2(0, -7), 1.5, Color8(255, 226, 158))