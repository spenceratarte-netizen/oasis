extends RefCounted
class_name ZoneParams

var zone_id := "sanctuary"
var zone_name := "Santuario Hundido"
var width := 56
var height := 36
var seed_value := 20260926
var border_thickness := 2
var rock_threshold := 0.62
var sand_scale := 0.16
var sand_threshold := 0.45
var ground_tile := TileKind.SAND
var pond := true

static func for_zone(id: String) -> ZoneParams:
	var result := ZoneParams.new()
	if id == "rift_forest":
		result.zone_id = "rift_forest"
		result.zone_name = "Bosque de la Grieta"
		result.seed_value = 20261014
		result.rock_threshold = 0.67
		result.sand_scale = 0.12
		result.sand_threshold = 0.49
		result.ground_tile = TileKind.GRASS
		result.pond = true
	return result