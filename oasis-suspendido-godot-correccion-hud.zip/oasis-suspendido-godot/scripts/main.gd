extends Node2D

@onready var world: World = $World
@onready var player: Player = $Player
@onready var hud: CanvasLayer = $HUD

func _ready() -> void:
	# The world owns its deterministic layout; Main only connects the playable
	# pieces so the scene remains easy to expand with more zones later.
	world.player_path = player.get_path()
	player.position = world.get_spawn_point()
	hud.call_deferred("connect_game", player, world)