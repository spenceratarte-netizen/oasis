extends CanvasLayer

@export var player_path: NodePath

var player
var world
var role_label: Label
var zone_label: Label
var level_label: Label
var gold_label: Label
var health_fill: ColorRect
var xp_fill: ColorRect
var status_label: Label
var ability_label: Label
var message_label: Label
var _message_timer := 0.0

const PANEL_COLOR := Color(0.035, 0.043, 0.09, 0.88)
const BORDER_COLOR := Color(0.44, 0.35, 0.62, 0.65)
const TEXT_COLOR := Color8(244, 230, 215)
const MUTED_COLOR := Color8(176, 165, 190)

func _ready() -> void:
	_build_ui()
	if player_path != NodePath(""):
		player = get_node_or_null(player_path)
		if player != null:
			call_deferred("connect_game", player, null)

func connect_game(new_player, new_world) -> void:
	player = new_player
	world = new_world
	if player != null:
		if not player.role_changed.is_connected(_on_role_changed):
			player.role_changed.connect(_on_role_changed)
		if not player.combat_event.is_connected(_on_game_message):
			player.combat_event.connect(_on_game_message)
		_on_role_changed(player.role)
	if world != null and not world.zone_changed.is_connected(_on_zone_changed):
		world.zone_changed.connect(_on_zone_changed)
		_on_zone_changed(world.zone_name)

func _build_ui() -> void:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	var title_panel := _make_panel(root, Vector2(22, 18), Vector2(284, 74))
	var title := _make_label(title_panel, "OASIS SUSPENDIDO", Vector2(18, 10), Vector2(250, 28), 18, TEXT_COLOR)
	title.add_theme_constant_override("outline_size", 4)
	title.add_theme_color_override("font_outline_color", Color(0.15, 0.1, 0.23, 0.95))
	zone_label = _make_label(title_panel, "SANTUARIO HUNDIDO  /  ZONA 01", Vector2(19, 40), Vector2(250, 20), 10, MUTED_COLOR)

	var role_panel := _make_panel(root, Vector2(22, 105), Vector2(180, 72))
	_make_label(role_panel, "CLASE ACTIVA", Vector2(16, 9), Vector2(145, 18), 10, MUTED_COLOR)
	role_label = _make_label(role_panel, "Arquero", Vector2(16, 27), Vector2(145, 30), 20, TEXT_COLOR)

	var health_panel := _make_panel(root, Vector2(22, 185), Vector2(180, 48))
	_make_label(health_panel, "VITALIDAD", Vector2(14, 7), Vector2(80, 15), 9, MUTED_COLOR)
	var health_back := _make_bar(health_panel, Vector2(14, 26), Vector2(152, 8), Color(0.12, 0.08, 0.17, 0.95))
	health_fill = _make_bar(health_back, Vector2.ZERO, Vector2(152, 8), Color8(111, 205, 163))

	var progress_panel := _make_panel(root, Vector2(22, 241), Vector2(180, 82))
	level_label = _make_label(progress_panel, "NIVEL 1", Vector2(14, 7), Vector2(70, 18), 11, TEXT_COLOR)
	gold_label = _make_label(progress_panel, "ORO 0", Vector2(91, 7), Vector2(74, 18), 10, Color8(240, 202, 119))
	_make_label(progress_panel, "EXPERIENCIA", Vector2(14, 29), Vector2(120, 15), 9, MUTED_COLOR)
	var xp_back := _make_bar(progress_panel, Vector2(14, 52), Vector2(152, 8), Color(0.12, 0.08, 0.17, 0.95))
	xp_fill = _make_bar(xp_back, Vector2.ZERO, Vector2(152, 8), Color8(185, 128, 238))

	var hint_panel := _make_panel(root, Vector2(22, 454), Vector2(500, 62))
	_make_label(hint_panel, "WASD MOVER   ESPACIO/J ATAQUE   Q HABILIDAD   E INTERACTUAR", Vector2(16, 8), Vector2(470, 20), 10, TEXT_COLOR)
	_make_label(hint_panel, "1 Arquero   2 Guerrero   3 Mago   4 Asesino", Vector2(16, 34), Vector2(390, 18), 10, MUTED_COLOR)

	var right_panel := _make_panel(root, Vector2(726, 18), Vector2(212, 82))
	status_label = _make_label(right_panel, "EXPLORANDO", Vector2(14, 8), Vector2(180, 18), 11, Color8(196, 224, 193))
	ability_label = _make_label(right_panel, "Q  Habilidad lista", Vector2(14, 29), Vector2(180, 17), 9, MUTED_COLOR)
	_make_label(right_panel, "CAMPO DE VISION AMPLIADO", Vector2(14, 56), Vector2(180, 14), 8, MUTED_COLOR)

	var message_panel := _make_panel(root, Vector2(548, 454), Vector2(390, 62))
	message_label = _make_label(message_panel, "Explora el santuario", Vector2(14, 9), Vector2(360, 42), 11, TEXT_COLOR)
	message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

func _make_bar(parent: Control, bar_position: Vector2, bar_size: Vector2, color: Color) -> ColorRect:
	var bar := ColorRect.new()
	bar.position = bar_position
	bar.size = bar_size
	bar.color = color
	parent.add_child(bar)
	return bar

func _make_panel(parent: Control, panel_position: Vector2, panel_size: Vector2) -> Panel:
	var panel := Panel.new()
	panel.position = panel_position
	panel.size = panel_size
	var style := StyleBoxFlat.new()
	style.bg_color = PANEL_COLOR
	style.border_color = BORDER_COLOR
	style.set_border_width_all(1)
	style.corner_radius_top_left = 8
	style.corner_radius_top_right = 8
	style.corner_radius_bottom_left = 8
	style.corner_radius_bottom_right = 8
	panel.add_theme_stylebox_override("panel", style)
	parent.add_child(panel)
	return panel

func _make_label(parent: Control, text: String, label_position: Vector2, label_size: Vector2, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.position = label_position
	label.size = label_size
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	parent.add_child(label)
	return label

func _process(delta: float) -> void:
	if player == null:
		return
	_message_timer = max(_message_timer - delta, 0.0)
	if role_label != null:
		role_label.text = player.get_role_label()
		role_label.add_theme_color_override("font_color", player.get_role_color())
	if level_label != null:
		level_label.text = "NIVEL %d  |  XP %d/%d" % [player.level, player.experience, player.experience_to_next_level()]
	if gold_label != null:
		gold_label.text = "ORO %d" % player.gold
	if health_fill != null:
		health_fill.size.x = 152.0 * player.get_health_ratio()
	if xp_fill != null:
		xp_fill.size.x = 152.0 * player.get_xp_ratio()
	if status_label != null:
		status_label.text = "DERROTADO" if player.dead else ("ATACANDO" if player.attack_cooldown > 0.0 else "EXPLORANDO")
	if ability_label != null:
		ability_label.text = "Q  %s" % player.get_ability_name()
		if player.ability_cooldown > 0.0:
			ability_label.text += "  %.1f s" % player.ability_cooldown
	if world != null and zone_label != null:
		zone_label.text = "%s  /  %s" % [world.zone_name.to_upper(), "ZONA 01" if world.current_zone_id == "sanctuary" else "ZONA 02"]

func _on_role_changed(_new_role: String) -> void:
	if player != null and role_label != null:
		role_label.text = player.get_role_label()
		role_label.add_theme_color_override("font_color", player.get_role_color())

func _on_zone_changed(new_zone: String) -> void:
	if zone_label != null:
		zone_label.text = new_zone.to_upper()
	_on_game_message("Nueva zona: %s" % new_zone)

func _on_game_message(message: String) -> void:
	if message_label != null:
		message_label.text = message
		_message_timer = 3.0