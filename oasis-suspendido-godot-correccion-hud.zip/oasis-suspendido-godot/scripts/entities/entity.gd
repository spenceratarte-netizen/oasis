extends Node2D
class_name Entity

# Equivalente a Entity.hpp. En Godot la posicion ya la da Node2D, asi que
# esta clase solo anade lo que raylib no traia de fabrica: tamano, bounds y
# estado de "viva".

var size := Vector2(28, 28)
var alive := true

func get_bounds() -> Rect2:
	return Rect2(position - size / 2.0, size)
