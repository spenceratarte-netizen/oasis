extends Entity
class_name Slime

@export var world_path: NodePath
@export_enum("red", "green", "blue") var variant := "green"

var world: World
var velocity := Vector2.ZERO
var target := Vector2.ZERO
var _sprite: Sprite2D
var _textures: Dictionary = {}
var _clock := 0.0
var _direction := 2
var _health := 3
var _attack_cooldown := 0.0
var _hurt_timer := 0.0
var _defeated := false

const COLORS := {
	"red": Color8(240, 92, 118),
	"green": Color8(122, 211, 98),
	"blue": Color8(98, 155, 242),
}

func _ready() -> void:
	size = Vector2(24, 18)
	add_to_group("slimes")
	if world_path != NodePath(""):
		world = get_node_or_null(world_path)
	_load_textures()
	_sprite = Sprite2D.new()
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_sprite.position = Vector2(0, -8)
	_sprite.scale = Vector2(0.82, 0.82)
	add_child(_sprite)
	_choose_target()
	_update_visual()
	queue_redraw()

func _physics_process(delta: float) -> void:
	if world == null:
		return
	_clock += delta
	_attack_cooldown = max(_attack_cooldown - delta, 0.0)
	_hurt_timer = max(_hurt_timer - delta, 0.0)
	var player := get_tree().get_first_node_in_group("player") as Player
	if player != null and not player.dead and global_position.distance_to(player.global_position) < 34.0 and _attack_cooldown <= 0.0:
		_attack_cooldown = 1.25
		player.take_damage(5, global_position.direction_to(player.global_position))
	if target.distance_to(position) < 18.0 or velocity.length() < 1.0:
		_choose_target()

	var direction := position.direction_to(target)
	velocity = velocity.lerp(direction * 38.0, 1.0 - exp(-3.5 * delta))
	if velocity.length_squared() > 16.0:
		_direction = 1 if abs(velocity.x) > abs(velocity.y) and velocity.x > 0.0 else _direction
		if abs(velocity.x) > abs(velocity.y) and velocity.x < 0.0:
			_direction = 3
		elif abs(velocity.y) >= abs(velocity.x):
			_direction = 2 if velocity.y > 0.0 else 0

	var next_position := position + velocity * delta
	if not world.check_collision(Rect2(next_position - size / 2.0, size)):
		position = next_position
	else:
		_choose_target()

	_update_visual()
	queue_redraw()

func _choose_target() -> void:
	if world == null:
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = int(position.x * 97.0 + position.y * 193.0 + _clock * 100.0)
	var candidate := position + Vector2(rng.randf_range(-130.0, 130.0), rng.randf_range(-100.0, 100.0))
	if not world.check_collision(Rect2(candidate - size / 2.0, size)):
		target = candidate
	else:
		target = position

func _load_textures() -> void:
	for state in ["idle", "walk", "attack", "hurt"]:
		var frames: Array[Texture2D] = []
		for direction in range(4):
			var texture_path := "res://assets/sprites/slime_%s_%s_%d.png" % [variant, state, direction]
			frames.append(load(texture_path) as Texture2D)
		_textures[state] = frames

func _update_visual() -> void:
	if _sprite == null:
		return
	var state := "hurt" if _hurt_timer > 0.0 else ("walk" if velocity.length() > 10.0 else "idle")
	var frames: Array = _textures.get(state, [])
	if frames.size() > _direction and frames[_direction] != null:
		_sprite.texture = frames[_direction]
	_sprite.position.y = -8.0 + sin(_clock * 5.0 + position.x * 0.02) * 1.5

func take_hit(amount: int = 1, direction := Vector2.ZERO) -> void:
	if _defeated:
		return
	_health = max(_health - amount, 0)
	_hurt_timer = 0.22
	if direction.length_squared() > 0.0:
		var pushed_position := position + direction.normalized() * 22.0
		if not world.check_collision(Rect2(pushed_position - size / 2.0, size)):
			position = pushed_position
	if _health == 0:
		_defeated = true
		var player := get_tree().get_first_node_in_group("player") as Player
		if player != null:
			player.gain_experience(20)
			player.combat_event.emit("Slime derrotado  +20 XP")
		queue_free()
	queue_redraw()

func _draw() -> void:
	var tint: Color = COLORS.get(variant, Color.WHITE)
	var points := PackedVector2Array()
	for i in range(20):
		var angle := TAU * float(i) / 20.0
		points.append(Vector2(cos(angle) * 17.0, 4.0 + sin(angle) * 5.0))
	draw_colored_polygon(points, Color(0.02, 0.03, 0.07, 0.42))
	draw_arc(Vector2(0, -3), 18.0, PI, TAU, 14, Color(tint, 0.36), 1.0)
	if _health < 3:
		draw_rect(Rect2(-15, -26, 30, 3), Color(0.06, 0.04, 0.09, 0.9))
		draw_rect(Rect2(-15, -26, 10 * _health, 3), tint)