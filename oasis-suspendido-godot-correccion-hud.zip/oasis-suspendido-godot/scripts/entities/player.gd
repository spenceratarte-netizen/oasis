extends Entity
class_name Player

signal role_changed(role_name: String)
signal stats_changed
signal combat_event(message: String)

@export var world_path: NodePath
@export_enum("archer", "warrior", "mage", "assassin") var role := "archer"

var world: World
var velocity := Vector2.ZERO
var knockback := Vector2.ZERO
var facing := Vector2.DOWN
var health := 100
var max_health := 100
var experience := 0
var level := 1
var gold := 0
var attack_cooldown := 0.0
var ability_cooldown := 0.0
var invulnerability := 0.0
var dead := false
var respawn_timer := 0.0

var _animation_clock := 0.0
var _last_visual_key := ""
var _sprite: Sprite2D
var _textures: Dictionary = {}
var _effect_timer := 0.0
var _effect_name := ""
var _effect_is_ability := false

const KNOCKBACK_DECAY := 7.0
const ROLES := ["archer", "warrior", "mage", "assassin"]
const ROLE_LABELS := {
	"archer": "Arquero",
	"warrior": "Guerrero",
	"mage": "Mago",
	"assassin": "Asesino",
}
const ROLE_COLORS := {
	"archer": Color8(103, 208, 176),
	"warrior": Color8(224, 132, 102),
	"mage": Color8(187, 128, 238),
	"assassin": Color8(126, 117, 193),
}
const ROLE_STATS := {
	"archer": {
		"speed": 178.0, "damage": 2, "cooldown": 0.38, "ability": 4.0,
		"health": 92, "attack_name": "Flecha precisa", "ability_name": "Lluvia de flechas",
	},
	"warrior": {
		"speed": 142.0, "damage": 3, "cooldown": 0.55, "ability": 3.2,
		"health": 125, "attack_name": "Tajo pesado", "ability_name": "Giro de acero",
	},
	"mage": {
		"speed": 150.0, "damage": 2, "cooldown": 0.62, "ability": 4.5,
		"health": 82, "attack_name": "Orbe arcano", "ability_name": "Nova de hielo",
	},
	"assassin": {
		"speed": 202.0, "damage": 4, "cooldown": 0.3, "ability": 3.0,
		"health": 78, "attack_name": "Corte veloz", "ability_name": "Paso sombrío",
	},
}

func _ready() -> void:
	size = Vector2(24, 20)
	add_to_group("player")
	if world_path != NodePath(""):
		world = get_node_or_null(world_path)
	_load_textures()
	_sprite = Sprite2D.new()
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_sprite.position = Vector2(0, -17)
	_sprite.scale = Vector2(0.72, 0.72)
	add_child(_sprite)
	set_role(role, false)
	queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	var key_event := event as InputEventKey
	if key_event.keycode >= KEY_1 and key_event.keycode <= KEY_4:
		set_role(ROLES[key_event.keycode - KEY_1])
	elif key_event.keycode == KEY_SPACE or key_event.keycode == KEY_J:
		_try_attack()
	elif key_event.keycode == KEY_Q:
		_try_ability()
	elif key_event.keycode == KEY_E:
		_try_interact()

func set_role(new_role: String, announce := true) -> void:
	if new_role not in ROLES:
		return
	role = new_role
	var role_stats: Dictionary = ROLE_STATS[role]
	max_health = int(role_stats["health"]) + (level - 1) * 10
	health = min(health, max_health)
	_animation_clock = 0.0
	_last_visual_key = ""
	if announce:
		role_changed.emit(role)
		stats_changed.emit()
	queue_redraw()

func get_role_label() -> String:
	return ROLE_LABELS.get(role, "Arquero")

func get_role_color() -> Color:
	return ROLE_COLORS.get(role, Color.WHITE)

func get_health_ratio() -> float:
	return clampf(float(health) / float(max_health), 0.0, 1.0)

func get_xp_ratio() -> float:
	return clampf(float(experience) / float(experience_to_next_level()), 0.0, 1.0)

func experience_to_next_level() -> int:
	return 50 + (level - 1) * 25

func get_zone_label() -> String:
	return world.get_zone_label() if world != null else "Santuario Hundido"

func get_attack_name() -> String:
	return str(ROLE_STATS[role]["attack_name"])

func get_ability_name() -> String:
	return str(ROLE_STATS[role]["ability_name"])

func _physics_process(delta: float) -> void:
	if world == null:
		return
	if dead:
		_process_respawn(delta)
		return
	attack_cooldown = max(attack_cooldown - delta, 0.0)
	ability_cooldown = max(ability_cooldown - delta, 0.0)
	invulnerability = max(invulnerability - delta, 0.0)
	_effect_timer = max(_effect_timer - delta, 0.0)
	_handle_movement(delta)
	_animation_clock += delta
	_update_visual()
	queue_redraw()

func _handle_movement(delta: float) -> void:
	var input_dir := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
		input_dir.y -= 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		input_dir.y += 1.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		input_dir.x -= 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		input_dir.x += 1.0
	if input_dir.length_squared() > 0.0:
		input_dir = input_dir.normalized()
		facing = input_dir

	var role_stats: Dictionary = ROLE_STATS[role]
	var target_velocity := input_dir * float(role_stats["speed"])
	var smoothing := 1.0 - exp(-1800.0 * delta / float(role_stats["speed"]))
	velocity = velocity.lerp(target_velocity, smoothing)
	var total := velocity + knockback
	position.x += total.x * delta
	if world.check_collision(get_bounds()):
		position.x -= total.x * delta
		velocity.x = 0.0
	position.y += total.y * delta
	if world.check_collision(get_bounds()):
		position.y -= total.y * delta
		velocity.y = 0.0
	knockback *= exp(-7.0 * delta)

func _try_attack() -> void:
	if dead or attack_cooldown > 0.0:
		return
	var role_stats: Dictionary = ROLE_STATS[role]
	attack_cooldown = float(role_stats["cooldown"])
	_effect_timer = 0.32
	_effect_name = "attack"
	_effect_is_ability = false
	_animation_clock = 0.0
	var damage := int(role_stats["damage"])
	match role:
		"archer":
			_hit_in_direction(245.0, 0.62, damage, "Flecha precisa")
		"warrior":
			_hit_in_direction(72.0, -0.15, damage, "Tajo pesado")
		"mage":
			_hit_in_radius(88.0, damage, "Orbe arcano")
		"assassin":
			_dash_toward_facing(38.0)
			_hit_in_direction(82.0, -0.2, damage, "Corte veloz")
	queue_redraw()

func _try_ability() -> void:
	if dead or ability_cooldown > 0.0:
		return
	var role_stats: Dictionary = ROLE_STATS[role]
	ability_cooldown = float(role_stats["ability"])
	_effect_timer = 0.6
	_effect_name = "ability"
	_effect_is_ability = true
	_animation_clock = 0.0
	match role:
		"archer":
			_hit_in_direction(300.0, 0.35, 3, "Lluvia de flechas")
			_hit_in_direction(300.0, -0.35, 3, "Lluvia de flechas")
		"warrior":
			_hit_in_radius(104.0, 4, "Giro de acero")
		"mage":
			_hit_in_radius(142.0, 4, "Nova de hielo")
		"assassin":
			_dash_toward_facing(105.0)
			_hit_in_radius(82.0, 5, "Paso sombrío")
	queue_redraw()

func _hit_in_direction(max_distance: float, minimum_dot: float, damage: int, message: String) -> void:
	var attack_direction := facing.normalized()
	var best_target: Node = null
	var best_distance := max_distance
	for target in get_tree().get_nodes_in_group("slimes"):
		if not is_instance_valid(target):
			continue
		var offset: Vector2 = target.global_position - global_position
		var distance := offset.length()
		if distance <= max_distance and attack_direction.dot(offset.normalized()) > minimum_dot and distance < best_distance:
			best_target = target
			best_distance = distance
	if best_target != null:
		best_target.take_hit(damage, attack_direction)
		combat_event.emit("%s  -%d" % [message, damage])

func _hit_in_radius(radius: float, damage: int, message: String) -> void:
	var hit_count := 0
	for target in get_tree().get_nodes_in_group("slimes"):
		if not is_instance_valid(target):
			continue
		if target.global_position.distance_to(global_position) <= radius:
			target.take_hit(damage, global_position.direction_to(target.global_position))
			hit_count += 1
	if hit_count > 0:
		combat_event.emit("%s  x%d" % [message, hit_count])

func _dash_toward_facing(distance: float) -> void:
	var destination := position + facing.normalized() * distance
	if not world.check_collision(Rect2(destination - size / 2.0, size)):
		position = destination

func _try_interact() -> void:
	if dead or world == null:
		return
	var message: String = world.interact_at(global_position)
	if not message.is_empty():
		combat_event.emit(message)

func take_damage(amount: int, direction := Vector2.ZERO) -> void:
	if dead or invulnerability > 0.0:
		return
	health = max(health - amount, 0)
	invulnerability = 0.8
	_effect_timer = 0.25
	_effect_name = "hurt"
	if direction.length_squared() > 0.0:
		apply_knockback(direction.normalized(), 130.0)
	combat_event.emit("Recibiste %d de daño" % amount)
	stats_changed.emit()
	if health <= 0:
		_defeat()

func _defeat() -> void:
	dead = true
	respawn_timer = 2.2
	velocity = Vector2.ZERO
	knockback = Vector2.ZERO
	if _sprite != null:
		_sprite.visible = false
	combat_event.emit("Has caído. Regresas al altar en %.1f s" % respawn_timer)
	queue_redraw()

func _process_respawn(delta: float) -> void:
	respawn_timer = max(respawn_timer - delta, 0.0)
	if respawn_timer > 0.0:
		queue_redraw()
		return
	dead = false
	position = world.get_spawn_point()
	health = max_health
	invulnerability = 1.2
	if _sprite != null:
		_sprite.visible = true
	combat_event.emit("Has vuelto al altar")
	stats_changed.emit()

func gain_experience(amount: int) -> void:
	experience += amount
	while experience >= experience_to_next_level():
		experience -= experience_to_next_level()
		level += 1
		max_health = int(ROLE_STATS[role]["health"]) + (level - 1) * 10
		health = max_health
		combat_event.emit("Nivel %d alcanzado" % level)
	stats_changed.emit()

func add_gold(amount: int) -> void:
	gold += amount
	stats_changed.emit()

func apply_knockback(direction: Vector2, force: float = 250.0) -> void:
	knockback += direction * force

func _load_textures() -> void:
	for role_name in ROLES:
		_textures[role_name] = {}
		for state in ["idle", "walk", "attack", "hurt"]:
			var frames: Array[Texture2D] = []
			for direction in range(4):
				var path := "res://assets/sprites/%s_%s_%d.png" % [role_name, state, direction]
				frames.append(load(path) as Texture2D)
			_textures[role_name][state] = frames

func _update_visual() -> void:
	if _sprite == null:
		return
	if dead:
		_sprite.visible = false
		return
	_sprite.visible = true
	var state := "hurt" if _effect_name == "hurt" and _effect_timer > 0.0 else ("attack" if _effect_timer > 0.0 else ("walk" if velocity.length() > 32.0 else "idle"))
	var direction := _direction_index()
	var frame := int(_animation_clock * 7.0) % 2 if state == "walk" else 0
	var key := "%s:%s:%d:%d" % [role, state, direction, frame]
	if key != _last_visual_key:
		_last_visual_key = key
		var frames: Array = _textures.get(role, {}).get(state, [])
		if frames.size() > direction and frames[direction] != null:
			_sprite.texture = frames[direction]
	_sprite.position.y = -17.0 + sin(_animation_clock * 8.0) * (1.5 if state == "walk" else 0.5)

func _direction_index() -> int:
	if abs(facing.x) > abs(facing.y):
		return 1 if facing.x > 0.0 else 3
	return 2 if facing.y > 0.0 else 0

func _draw() -> void:
	var accent: Color = get_role_color()
	draw_ellipse(Vector2(0, 4), Vector2(19, 7), Color(0.02, 0.03, 0.07, 0.52))
	if dead:
		draw_arc(Vector2.ZERO, 28.0 + sin(_animation_clock * 5.0) * 3.0, 0.0, TAU, 32, Color(0.9, 0.5, 0.65, 0.8), 2.0)
		return
	draw_arc(Vector2.ZERO, 21.0, 0.0, TAU, 32, Color(accent, 0.28), 1.0)
	if _effect_timer > 0.0 and _effect_name != "hurt":
		var direction := facing.normalized()
		if role == "archer":
			var length := 160.0 if _effect_is_ability else 110.0
			var end_point := direction * length
			draw_line(direction * 17.0, end_point, Color(accent, 0.95), 2.0)
			draw_line(end_point, end_point - direction * 12.0 + direction.rotated(PI / 2.0) * 7.0, Color(1.0, 0.88, 0.66, 0.9), 2.0)
			draw_line(end_point, end_point - direction * 12.0 - direction.rotated(PI / 2.0) * 7.0, Color(1.0, 0.88, 0.66, 0.9), 2.0)
		elif role == "warrior":
			draw_arc(Vector2.ZERO, 52.0 if _effect_is_ability else 40.0, -1.3, 1.3, 18, Color(accent, 0.95), 5.0)
		elif role == "mage":
			var radius := 68.0 if _effect_is_ability else 38.0
			draw_circle(Vector2.ZERO, radius * (1.0 - _effect_timer * 0.25), Color(accent, 0.12), false, 4.0)
			draw_circle(direction * 30.0, 10.0 if _effect_is_ability else 6.0, Color(0.8, 0.92, 1.0, 0.85))
		else:
			draw_line(direction.rotated(0.45) * 10.0, direction.rotated(-0.45) * 74.0, Color(accent, 0.95), 4.0)
			draw_line(direction.rotated(-0.45) * 10.0, direction.rotated(0.45) * 74.0, Color(0.95, 0.82, 1.0, 0.78), 3.0)
	if role == "archer":
		var bow_center := facing.normalized() * 13.0
		var perpendicular := Vector2(-facing.y, facing.x) * 7.0
		draw_arc(bow_center, 7.0, -1.25, 1.25, 12, accent, 2.0)
		draw_line(bow_center - perpendicular, bow_center + perpendicular, Color(0.93, 0.81, 0.62, 0.9), 1.0)

func draw_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(24):
		var angle := TAU * float(i) / 24.0
		points.append(center + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
	draw_colored_polygon(points, color)